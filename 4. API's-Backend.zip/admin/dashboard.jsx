import React from 'react'


class Dashboard extends React.Component {
    constructor(props) {
        super(props);
    }


    render() {
        return (
            // <div id="google_translate_element"></div>
            <h1 style={{ color: 'gray', fontSize: "30px", textAlign: "center", paddingTop: "25%" }}>Welcome to PrimeShopper</h1>
        );
    }
}
export default Dashboard