AdminBro.UserComponents = {}
import Component1 from '../admin/dashboard'
AdminBro.UserComponents.Component1 = Component1
import Component2 from '../admin/ShowImage'
AdminBro.UserComponents.Component2 = Component2
import Component3 from '../admin/ShowImage'
AdminBro.UserComponents.Component3 = Component3
import Component4 from '../admin/ImageUpload'
AdminBro.UserComponents.Component4 = Component4
import Component5 from '../admin/ImageUpload'
AdminBro.UserComponents.Component5 = Component5
import Component6 from '../admin/ShowImage'
AdminBro.UserComponents.Component6 = Component6
import Component7 from '../admin/ShowImage'
AdminBro.UserComponents.Component7 = Component7
import Component8 from '../admin/ImageUpload'
AdminBro.UserComponents.Component8 = Component8
import Component9 from '../admin/ImageUpload'
AdminBro.UserComponents.Component9 = Component9
import Component10 from '../admin/ShowImage'
AdminBro.UserComponents.Component10 = Component10
import Component11 from '../admin/ShowImage'
AdminBro.UserComponents.Component11 = Component11
import Component12 from '../admin/ImageUpload'
AdminBro.UserComponents.Component12 = Component12
import Component13 from '../admin/ImageUpload'
AdminBro.UserComponents.Component13 = Component13
import Component14 from '../admin/ShowImage'
AdminBro.UserComponents.Component14 = Component14
import Component15 from '../admin/ShowImage'
AdminBro.UserComponents.Component15 = Component15
import Component16 from '../admin/ImageUpload'
AdminBro.UserComponents.Component16 = Component16
import Component17 from '../admin/ImageUpload'
AdminBro.UserComponents.Component17 = Component17
import Component18 from '../admin/ShowImage'
AdminBro.UserComponents.Component18 = Component18
import Component19 from '../admin/ShowImage'
AdminBro.UserComponents.Component19 = Component19
import Component20 from '../admin/ImageUpload'
AdminBro.UserComponents.Component20 = Component20
import Component21 from '../admin/ImageUpload'
AdminBro.UserComponents.Component21 = Component21