// const io = require("socket.io-client");
// const socket = io("http://localhost:8080/");


// var data = {
//     token : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiNjE0ODcyYjkxMGQ1YTNiZTAzNGY0OGJkIiwiaWF0IjoxNjMyNzIxOTI3fQ.8OdE8Y3uc791Wduj2TciQUDIAsfMXj4Dqh3O8jVXaTk'
// }
// var msgData = {
//     token : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiNjE0ODcyYjkxMGQ1YTNiZTAzNGY0OGJkIiwiaWF0IjoxNjMyNzIxOTI3fQ.8OdE8Y3uc791Wduj2TciQUDIAsfMXj4Dqh3O8jVXaTk',
//     user : '6149b5285d9acbbd518db555',
//     from : '6149b5285d9acbbd518db555',
//     to : '6151601af50eab5ec75884b6',
//     message : 'Hello Buddy!',
// }
// socket.emit("IAMAVAILABEL", data)
// socket.emit("CHAT_MESSAGE_TO_CUSTOMER",msgData)


// socket.on("WELCOME", function(msg) {
// })

// socket.on("connect", function() {
//     console.log('connected');
// })


// socket.on("error",function(err) {
//     console.log(err);
// })
